/*as linhas abaixo chamam as bibliotecas*/
#include <stdio.h>// define entrada e saida
#include <stdlib.h>//comandos basicos
#include <locale.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {

	// a linha a baixo configura o idioma para portugues
	setlocale(LC_ALL,"Portuguese");
	system("color 5E"); // quando tem apenas 1 digito se refere a cor do texto e com 2 o primeiro e da dor do fundo e o segundo do texto 
	printf("\n Ol� Mundo \n"); //\n Pula linha
	system("pause");
	system("cls");//limpa tela
	system("color 0F");
	printf("Professor Jos� de Assis \n");
	system("pause");
	return 0;//Retorna 0 quando na tem erro

}
