// as linhas abaixo chamam as bibliotecas
//#include <stdio.h>//define a entrada e saida
#include <stdlib.h>//comandos basicos

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	printf("Hello World");
	system(pause);
	return 0;
}
