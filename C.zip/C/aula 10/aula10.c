#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
//aula 10 array/vetor

int main(int argc, char *argv[]) {
	float nota1 = 8;
	float nota2 = 6;
	float nota3 = 9;
	float nota4 = 3;
	
	//Exibindo o conteudo da variavel nota3 sem uso do array
	printf("Sem array\n");
	printf("Nota: % .1f\n", nota3);//exibe a nota da variavel nota3 com 1 casa decimal (1 numero depois do ponto)
	
	// a linha abaixo cria um array de tamanho 4
	float notas [4]={8,6,9,3};//tipo de variavel nome da variavel, numero de itens no [] e valores entre {}
	printf("Com array\n");
	printf("Nota3; %.1f\n", notas[2]);// puxa o conteudo do indice 2 do vetor notas
	
	// a linha abaixo modifica o conteudo de um array
	notas [1]=7;
	printf("Modificando o conteudo do array\n");
	printf("Nota2; %.1f\n", notas[1]);

	//A linha abaixo cria u array de duas diemnssoes conforme a nota do aluno (faz uma tabela)
	float boletim[2][4]={{8,7,9,3},{4,5,8,6}};//2 linha e 4 colunas
	//recuperando a nota de portugues do 1� bimestre
	printf("Array multidimensional\n");
	printf("Nota: %.f\n", boletim[1][0]);//linha 1 coluna 0
	system("pause");
	return 0;
}
