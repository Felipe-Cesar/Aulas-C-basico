#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	char nome[30];
	printf("Digite o seu nome: ");
	gets(nome);//le o que o usuario escreveu e coloca na variavel nome
	system("cls");
	printf("Bem vindo %s\n",nome);//%s == avisa a memoria que � um tipo de variavel � string e \n == pula uma linha
	
	system("pause");
	return 0;
	
}
