#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	
	int idade;
	printf("Digite a sua idade: ");
	scanf("%d", &idade); //le o que for digitado no teclado e armazena na variavel %d le dados do tipo int
	printf("Idade: %d", idade);//%d exibe o conteudo da variavel idade
	// a linha abaixo executa uma estrutura de decis�o
	if (idade<18){
		printf("\nmenor de idade\n");	
	}else{
		printf("\nmaior de idade\n");
	}
	system("pause");
	return 0;
	
}
