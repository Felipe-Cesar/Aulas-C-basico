#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
//switch case

int numero;

int main(int argc, char *argv[]) {
	
	
	printf("Sistemas\n\n");
	printf("1- Windows\n");
	printf("2- Linux\n");
	printf("\nEscolha a op��o desejada: ");
	scanf("%d", &numero);
	switch(numero){
		
		case 1: // se numero == 1 fa�a
			system("cls");
			printf("Iniciando o windows...\n");
			break;//finaliza o case1
			
		case 2: // se numero == 2 fa�a
			system("cls");
			printf("Iniciando o Linux...\n");
			break;//finaliza o case2
			
		default: //senao fa�a
			printf("Op�ao invalida");
	}
	system("pause");
	return 0;	
}
