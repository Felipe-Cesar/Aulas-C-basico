#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
//Fun��es

void teste(void);

int main(int argc, char *argv[]) {
	
	printf("Exemplo de funcao\n\n");
	teste();
	teste();
	printf("Fim\n");
	system("pause");
	return 0;
}

void teste(void){
	
	printf("Professor Jose de Assis\n");
	
}
