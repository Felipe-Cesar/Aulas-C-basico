#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
//aula8 estrutura de repeti��o

int numero,resposta;
int contador = 0;

int main(int argc, char *argv[]) {
	do{//executa a tabuada enquanto o teste logico foi verdadeiro

		system("cls");
		printf("tabuada\n\n");
		printf("Digite o numero da tabuada: ");
		scanf("%d", &numero);
		// a linha abaixo gera um la�o finito
		for (contador=0; contador<=10;contador++){//contador=contador+1
			printf("%d x %d = %d\n", numero, contador,numero*contador);
		}
		printf("\n1- Novo calculo\n");
		printf("2- Sair\n");
		scanf("%d", &resposta);
		printf("Digite a opcao desejada: ");
	}while(resposta != 2);//enquanto resposta diferente de 2 cotinue repetindo o la�o
	system("pause");
	return 0;
}
