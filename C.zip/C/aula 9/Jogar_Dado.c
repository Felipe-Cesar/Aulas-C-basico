#include <stdio.h>
#include <stdlib.h>
#include <time.h>//biblioteca com varias funcoes de medicao de tempo

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	printf("Jogo do dado\n");
	srand(time(NULL));// inicia o gerador de numeros aleatorios usando a biblioteca time
	printf("Face: %d\n", rand()%6 + 1);//rand %6 gera numeros aleatorios entre 0 e 5 e rand %6 + 1 gera numeros aleatorios entre 1 e 6
	system("pause");
	
	return 0;
}

